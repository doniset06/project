package com.example.projectandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityChoose extends AppCompatActivity implements View.OnClickListener {
    CardView cardView1;
    CardView cardView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        cardView1 = (CardView)findViewById(R.id.card1);
        cardView1.setOnClickListener(this);
        cardView2 = (CardView)findViewById(R.id.card2);
        cardView2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.card1 :
                Intent student = new Intent(ActivityChoose.this, LoginStudent.class);
                startActivity(student);
                break;
            case R.id.card2 :
                Intent teacher = new Intent(ActivityChoose.this, LoginTeacher.class);
                startActivity(teacher);
                break;
            default:
                break;
        }
    }
}
